/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjetImageJ;

import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import ij.WindowManager;
import ij.process.ImageConverter;
import ij.process.ImageProcessor;

/**
 *
 * @author nicholasjournet
 */
public class Main {

    public static void main(String[] args) {
        new ImageJ();
        ImagePlus image = IJ.openImage("/Users/nicholasjournet/Desktop/test.png");
        IJ.showMessage("Accès à ImageJ depuis le code source");
        new ImageConverter(image).convertToGray8();
        ImageProcessor ip = image.getProcessor();

        byte[] pixels = (byte[]) ip.getPixels();
        int height = ip.getHeight();
        int width = ip.getWidth();
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int pix = pixels[i * width + j] & 0xff;
                if (pix < 120) {
                    pixels[i * width + j] = (byte) 0;
                } else {
                    pixels[i * width + j] = (byte) 255;
                }
            }
        }
        image.show();
        WindowManager.addWindow(image.getWindow());
    }
}
